### Cologne1
|  File   | Desc  |
|  ----  | ----  |
| cologne1.*  | modify some settings,junctions.limit-turn-speed,etc. |
| cologne1_or.*  | origin file |

cmd: netconvert -s /home/leo/LibSignalSpare/data/raw_data/cologne3/cologne3.net.xml -o /home/leo/LibSignalSpare/data/raw_data/cologne3/mycologne3.net.xml --no-turnarounds true --junctions.corner-detail 5 --junctions.limit-turn-speed 5.5 